sr.fn.session.logout = function() {
  $("#logoutform").submit();
}